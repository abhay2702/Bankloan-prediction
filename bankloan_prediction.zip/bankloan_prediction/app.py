# -*- coding: utf-8 -*-

from flask import Flask, request, jsonify, render_template

import os
import numpy as np
import pickle

# Load ML model
model = pickle.load(open('model3.pkl', 'rb')) 

# Create application
app = Flask(__name__)

# Bind home function to URL
@app.route('/')
def home():
    return render_template('index.html')

# Bind predict function to URL
@app.route('/predict', methods =['POST'])
def predict():
    
    # Put all form entries values in a list 
    features = [float(x) for x in request.form.values()]
    # Convert features to array
    array_features = [np.array(features)]
    # Predict features
    prediction = model.predict(array_features)
    
    output = round(prediction[0])
    
    # Check the output values and retrive the result with html tag based on the value
    if output == 0:
        return render_template('index.html', 
                               result = 'Sorry!!! You are not eligible for loan')
    else:
        return render_template('index.html', 
                               result ='Congratulations!!! You are eligible for the loan' )

if __name__ == '__main__':
#Run the application
    app.run(debug=True)
    
    