import pandas as pd
import numpy as np
import seaborn as sns
sns.set(color_codes=True)
from matplotlib import pyplot as plt
import matplotlib
# %matplotlib inline
import pickle
# name = ['APP_ID', 'CIBIL_SCORE_VALUE', 'NEW_CUST',	'CUS_CATGCODE', 'EMPLOYMENT_TYPE' , 'AGE', 'SEX', 'NO_OF_DEPENDENTS', 'MARITAL', 'EDU_QUA', 'P_RESTYPE', 'P_CATEGORY', 'EMPLOYEE_TYPE', 'MON_IN_OCC', 'INCOM_EXP_G1I', 'LTV', 'TENURE', 'STATUS']

df = pd.read_csv("bankloan.csv")
df.head()

df.describe()
df.info()

#drop unnecessary columns
cols = ['APP_ID']
df = df.drop(columns=cols, axis= 1)
df.head()

from sklearn.preprocessing import LabelEncoder
cols = ["NEW_CUST"]
le = LabelEncoder()
for col in cols:
    df[col] = le.fit_transform(df[col])

df.head()

x = df.drop(columns=['STATUS'], axis=1)
y = df['STATUS']

from sklearn.model_selection import train_test_split
from sklearn import model_selection
from sklearn import ensemble
x_train, x_test, y_train, y_test =train_test_split(x, y, test_size=0.25,random_state=20)

clf =ensemble.RandomForestClassifier(n_estimators=50, min_samples_split=100, max_depth=14, max_features=2)
clf.fit(x_train,y_train)
pred = clf.predict(x_test)
accuracy = clf.score(x_test,y_test)
train_score = clf.score(x_train,y_train)
cr = classification_report(y_test, pred)


print("Test_Score:",accuracy)
print("Train_Score:",train_score)
print("Classification rep[ort]:\n ",cr)

pickle.dump(clf,open('model3.pkl','wb'))

model=pickle.load(open('model3.pkl','rb'))

print(model.predict(x_test))


# #classify function
# from sklearn.model_selection import cross_val_score
# def classify(model, x, y):
#     x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.25,random_state=42)
#     model.fit(x_train, y_train)
#     print("Accuracy is", model.score(x_test, y_test)*100)

#     # cross validation = it is used for better validation of model
#     #eg: cv-5, train-4, test-1
#     score = cross_val_score(model, x, y, cv=5)
#     print("Cross Validation is",np.mean(score)*100)

#     from sklearn.ensemble import RandomForestClassifier
#     model = RandomForestClassifier(n_estimators=100, min_samples_split=200, max_depth=28, max_features=4)
# classify(model, x, y)

# with open('model3.pkl', 'wb') as file:
#     pickle.dump(model, file)